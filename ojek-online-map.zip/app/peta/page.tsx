"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import dynamic from "next/dynamic"
import { ArrowLeft, RefreshCw, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"

// Dynamically import the Map component to avoid SSR issues with Leaflet
const MapComponent = dynamic(() => import("@/components/map-component"), {
  ssr: false,
  loading: () => <div className="w-full h-screen flex items-center justify-center">Loading map...</div>,
})

export default function PetaPage() {
  const { toast } = useToast()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [filters, setFilters] = useState({
    jenisLokasi: "all",
    tingkatKepadatan: [1, 5],
    tingkatKeamanan: [1, 5],
    kenyamanan: [1, 5],
  })
  const [geoJsonData, setGeoJsonData] = useState(null)
  const [filteredData, setFilteredData] = useState(null)

  // Load default GeoJSON data
  useEffect(() => {
    // In a real app, you would load your GeoJSON file here
    // For now, we'll use a placeholder
    const defaultData = {
      type: "FeatureCollection",
      features: [
        {
          type: "Feature",
          properties: {
            nama_lokasi: "Terminal Pulogadung",
            jenis_lokasi: "Terminal",
            jam_ramainya: "06:00 - 10:00 & 16:00 - 20:00",
            tingkat_kepadatan: 5,
            tingkat_keamanan: 4,
            akses_internet: "baik",
            kenyamanan: 4,
            fasilitas: "Tempat duduk, warung, toilet",
            alamat: "Jl. Pulo Gadung No.1, Jakarta Timur",
          },
          geometry: {
            type: "Point",
            coordinates: [106.8924, -6.1934],
          },
        },
        {
          type: "Feature",
          properties: {
            nama_lokasi: "Minimarket Indomaret Kalibata",
            jenis_lokasi: "Minimarket",
            jam_ramainya: "07:00 - 09:00 & 17:00 - 19:00",
            tingkat_kepadatan: 3,
            tingkat_keamanan: 4,
            akses_internet: "sedang",
            kenyamanan: 3,
            fasilitas: "Tempat duduk",
            alamat: "Jl. Kalibata Raya No.10, Jakarta Selatan",
          },
          geometry: {
            type: "Point",
            coordinates: [106.8536, -6.2551],
          },
        },
        {
          type: "Feature",
          properties: {
            nama_lokasi: "Perumahan Cibubur Indah",
            jenis_lokasi: "Perumahan",
            jam_ramainya: "06:30 - 08:30 & 17:30 - 19:30",
            tingkat_kepadatan: 4,
            tingkat_keamanan: 5,
            akses_internet: "baik",
            kenyamanan: 5,
            fasilitas: "Tempat duduk, warung",
            alamat: "Jl. Cibubur Indah No.5, Jakarta Timur",
          },
          geometry: {
            type: "Point",
            coordinates: [106.8845, -6.3571],
          },
        },
      ],
    }

    setGeoJsonData(defaultData)
    setFilteredData(defaultData)
  }, [])

  // Handle file upload
  const handleFileUpload = (event) => {
    const file = event.target.files[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target.result)
        setGeoJsonData(data)
        setFilteredData(data)
        toast({
          title: "Data berhasil diupload",
          description: `File ${file.name} berhasil dimuat.`,
        })
      } catch (error) {
        toast({
          title: "Error saat memproses file",
          description: "File GeoJSON tidak valid.",
          variant: "destructive",
        })
      }
    }
    reader.readAsText(file)
  }

  // Apply filters and search
  useEffect(() => {
    if (!geoJsonData) return

    const filtered = { ...geoJsonData }
    filtered.features = geoJsonData.features.filter((feature) => {
      const props = feature.properties

      // Filter by jenis_lokasi
      if (filters.jenisLokasi !== "all" && props.jenis_lokasi !== filters.jenisLokasi) {
        return false
      }

      // Filter by tingkat_kepadatan
      if (
        props.tingkat_kepadatan < filters.tingkatKepadatan[0] ||
        props.tingkat_kepadatan > filters.tingkatKepadatan[1]
      ) {
        return false
      }

      // Filter by tingkat_keamanan
      if (props.tingkat_keamanan < filters.tingkatKeamanan[0] || props.tingkat_keamanan > filters.tingkatKeamanan[1]) {
        return false
      }

      // Filter by kenyamanan
      if (props.kenyamanan < filters.kenyamanan[0] || props.kenyamanan > filters.kenyamanan[1]) {
        return false
      }

      // Search by name or address
      if (searchQuery) {
        const query = searchQuery.toLowerCase()
        return props.nama_lokasi.toLowerCase().includes(query) || props.alamat.toLowerCase().includes(query)
      }

      return true
    })

    setFilteredData(filtered)
  }, [geoJsonData, filters, searchQuery])

  // Reset filters
  const resetFilters = () => {
    setFilters({
      jenisLokasi: "all",
      tingkatKepadatan: [1, 5],
      tingkatKeamanan: [1, 5],
      kenyamanan: [1, 5],
    })
    setSearchQuery("")
    setFilteredData(geoJsonData)
  }

  return (
    <div className="flex flex-col h-screen">
      <header className="px-4 lg:px-6 h-16 flex items-center border-b">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <ArrowLeft className="h-5 w-5" />
          <span>Kembali</span>
        </Link>
        <div className="ml-auto flex items-center gap-4">
          <Button variant="outline" size="sm" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? "Sembunyikan Filter" : "Tampilkan Filter"}
          </Button>
        </div>
      </header>
      <div className="flex flex-1 overflow-hidden">
        <aside
          className={cn(
            "w-80 border-r bg-background p-4 overflow-y-auto transition-all duration-300",
            sidebarOpen ? "block" : "hidden",
          )}
        >
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-semibold mb-2">Pencarian</h2>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Cari lokasi..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            <Separator />
            <div>
              <h2 className="text-lg font-semibold mb-2">Filter</h2>
              <Tabs defaultValue="jenis">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="jenis">Jenis Lokasi</TabsTrigger>
                  <TabsTrigger value="rating">Rating</TabsTrigger>
                </TabsList>
                <TabsContent value="jenis" className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="jenis-lokasi">Jenis Lokasi</Label>
                    <Select
                      value={filters.jenisLokasi}
                      onValueChange={(value) => setFilters({ ...filters, jenisLokasi: value })}
                    >
                      <SelectTrigger id="jenis-lokasi">
                        <SelectValue placeholder="Semua jenis lokasi" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Semua</SelectItem>
                        <SelectItem value="Terminal">Terminal</SelectItem>
                        <SelectItem value="Minimarket">Minimarket</SelectItem>
                        <SelectItem value="Perumahan">Perumahan</SelectItem>
                        <SelectItem value="Pinggir jalan">Pinggir jalan</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </TabsContent>
                <TabsContent value="rating" className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>
                        Tingkat Kepadatan ({filters.tingkatKepadatan[0]}-{filters.tingkatKepadatan[1]})
                      </Label>
                    </div>
                    <Slider
                      defaultValue={[1, 5]}
                      min={1}
                      max={5}
                      step={1}
                      value={filters.tingkatKepadatan}
                      onValueChange={(value) => setFilters({ ...filters, tingkatKepadatan: value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>
                        Tingkat Keamanan ({filters.tingkatKeamanan[0]}-{filters.tingkatKeamanan[1]})
                      </Label>
                    </div>
                    <Slider
                      defaultValue={[1, 5]}
                      min={1}
                      max={5}
                      step={1}
                      value={filters.tingkatKeamanan}
                      onValueChange={(value) => setFilters({ ...filters, tingkatKeamanan: value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>
                        Kenyamanan ({filters.kenyamanan[0]}-{filters.kenyamanan[1]})
                      </Label>
                    </div>
                    <Slider
                      defaultValue={[1, 5]}
                      min={1}
                      max={5}
                      step={1}
                      value={filters.kenyamanan}
                      onValueChange={(value) => setFilters({ ...filters, kenyamanan: value })}
                    />
                  </div>
                </TabsContent>
              </Tabs>
            </div>
            <Separator />
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-semibold mb-2">Update Data</h2>
                <div className="grid w-full max-w-sm items-center gap-1.5">
                  <Label htmlFor="geojson-upload">Upload GeoJSON</Label>
                  <div className="flex w-full items-center gap-2">
                    <Input
                      id="geojson-upload"
                      type="file"
                      accept=".json,.geojson"
                      className="w-full"
                      onChange={handleFileUpload}
                    />
                  </div>
                </div>
              </div>
              <Button variant="outline" className="w-full" onClick={resetFilters}>
                <RefreshCw className="mr-2 h-4 w-4" />
                Reset Filter
              </Button>
            </div>
          </div>
        </aside>
        <main className="flex-1 overflow-hidden">{filteredData && <MapComponent geoJsonData={filteredData} />}</main>
      </div>
    </div>
  )
}
