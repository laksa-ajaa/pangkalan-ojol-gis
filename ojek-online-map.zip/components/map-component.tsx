"use client"

import { useEffect, useState } from "react"
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet"
import L from "leaflet"
import "leaflet/dist/leaflet.css"
import { Star } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

// Fix Leaflet icon issues
const defaultIcon = L.icon({
  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
})

L.Marker.prototype.options.icon = defaultIcon

// Component to set the map view
function SetMapView({ coordinates }) {
  const map = useMap()

  useEffect(() => {
    if (coordinates && coordinates.length > 0) {
      map.setView(coordinates, 12)
    }
  }, [coordinates, map])

  return null
}

// Custom marker component
function CustomMarker({ feature }) {
  const { properties, geometry } = feature
  const coordinates = [geometry.coordinates[1], geometry.coordinates[0]]

  // Create custom icon based on kepadatan
  const getMarkerColor = (kepadatan) => {
    switch (kepadatan) {
      case 5:
        return "text-red-500"
      case 4:
        return "text-orange-500"
      case 3:
        return "text-yellow-500"
      case 2:
        return "text-green-500"
      case 1:
        return "text-blue-500"
      default:
        return "text-gray-500"
    }
  }

  return (
    <Marker position={coordinates}>
      <Popup>
        <Card className="w-[300px] border-none shadow-none">
          <CardHeader className="p-3 pb-0">
            <CardTitle className="text-base">{properties.nama_lokasi}</CardTitle>
            <Badge variant="outline" className="w-fit">
              {properties.jenis_lokasi}
            </Badge>
          </CardHeader>
          <CardContent className="p-3 pt-2 space-y-2 text-sm">
            <div>
              <p className="font-semibold">Jam Ramai:</p>
              <p>{properties.jam_ramainya}</p>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className="font-semibold">Kepadatan:</p>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${i < properties.tingkat_kepadatan ? getMarkerColor(properties.tingkat_kepadatan) : "text-gray-300"}`}
                      fill={i < properties.tingkat_kepadatan ? "currentColor" : "none"}
                    />
                  ))}
                </div>
              </div>
              <div>
                <p className="font-semibold">Keamanan:</p>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${i < properties.tingkat_keamanan ? "text-green-500" : "text-gray-300"}`}
                      fill={i < properties.tingkat_keamanan ? "currentColor" : "none"}
                    />
                  ))}
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className="font-semibold">Kenyamanan:</p>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${i < properties.kenyamanan ? "text-blue-500" : "text-gray-300"}`}
                      fill={i < properties.kenyamanan ? "currentColor" : "none"}
                    />
                  ))}
                </div>
              </div>
              <div>
                <p className="font-semibold">Internet:</p>
                <Badge
                  variant="outline"
                  className={`
                  ${
                    properties.akses_internet === "baik"
                      ? "bg-green-100 text-green-800"
                      : properties.akses_internet === "sedang"
                        ? "bg-yellow-100 text-yellow-800"
                        : "bg-red-100 text-red-800"
                  }
                `}
                >
                  {properties.akses_internet}
                </Badge>
              </div>
            </div>
            <div>
              <p className="font-semibold">Fasilitas:</p>
              <p>{properties.fasilitas}</p>
            </div>
            <div>
              <p className="font-semibold">Alamat:</p>
              <p>{properties.alamat}</p>
            </div>
          </CardContent>
        </Card>
      </Popup>
    </Marker>
  )
}

export default function MapComponent({ geoJsonData }) {
  const [center, setCenter] = useState([-6.2088, 106.8456]) // Default: Jakarta
  const [markers, setMarkers] = useState([])

  useEffect(() => {
    if (geoJsonData && geoJsonData.features && geoJsonData.features.length > 0) {
      setMarkers(geoJsonData.features)

      // Calculate center from all points
      if (geoJsonData.features.length > 0) {
        const lats = geoJsonData.features.map((f) => f.geometry.coordinates[1])
        const lngs = geoJsonData.features.map((f) => f.geometry.coordinates[0])

        const avgLat = lats.reduce((a, b) => a + b, 0) / lats.length
        const avgLng = lngs.reduce((a, b) => a + b, 0) / lngs.length

        setCenter([avgLat, avgLng])
      }
    }
  }, [geoJsonData])

  return (
    <MapContainer center={center} zoom={12} style={{ height: "100%", width: "100%" }} zoomControl={false}>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <SetMapView coordinates={center} />
      {markers.map((feature, index) => (
        <CustomMarker key={index} feature={feature} />
      ))}
    </MapContainer>
  )
}
